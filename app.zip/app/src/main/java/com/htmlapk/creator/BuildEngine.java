package com.htmlapk.creator;

import android.net.Uri;

import java.io.File;

/**
 * APK बनाने वाला engine. UI सिर्फ इस interface को जानता है.
 * आज: LocalPatchEngine (फ़ोन पर, offline). बाद में चाहें तो CloudBuildEngine इसी interface पर लगाया जा सकता है,
 * UI में कोई बदलाव नहीं होगा.
 */
interface BuildEngine {
    interface Progress { void on(int percent); }

    final class Request {
        final File webRoot;
        final String appName;
        final String packageName;
        final Uri iconUri; // null = default icon

        Request(File webRoot, String appName, String packageName, Uri iconUri) {
            this.webRoot = webRoot;
            this.appName = appName;
            this.packageName = packageName;
            this.iconUri = iconUri;
        }
    }

    /** तैयार, signed APK की file लौटाता है. */
    File build(Request request, Progress progress) throws Exception;
}
