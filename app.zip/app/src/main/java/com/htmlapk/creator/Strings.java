package com.htmlapk.creator;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashMap;
import java.util.Map;

/** English / हिंदी text. Default: English. */
final class Strings {
    private static final Map<String, String> EN = new HashMap<>();
    private static final Map<String, String> HI = new HashMap<>();
    private static boolean hindi;

    static {
        put("subtitle", "Turn your HTML into an Android app", "अपने HTML को Android app में बदलें");
        put("step1", "① HTML Project", "① HTML Project");
        put("choose_html", "📁 Choose HTML", "📁 HTML चुनें");
        put("step2", "② App Name", "② App का नाम");
        put("name_hint", "My App", "My App");
        put("step3", "③ App Icon (Optional)", "③ App Icon (वैकल्पिक)");
        put("choose_icon", "🖼️ Choose Icon", "🖼️ Icon चुनें");
        put("icon_default", "No icon chosen. A simple default icon will be used.", "Icon नहीं चुना। एक सरल default icon लगेगा।");
        put("icon_chosen", "✓ Icon selected", "✓ Icon चुन लिया");
        put("create", "🚀 CREATE APK", "🚀 APK बनाएं");

        put("pick_title", "What do you want to choose?", "आप क्या चुनना चाहते हैं?");
        put("pick_html", "A single HTML file", "एक HTML file");
        put("pick_zip", "A ZIP file of my project", "मेरे project की ZIP file");
        put("pick_folder", "A project folder", "Project folder");
        put("reading", "Reading your project…", "आपका project पढ़ा जा रहा है…");
        put("project_ready", "✓ Ready: ", "✓ तैयार: ");

        put("progress_title", "Creating your APK...", "आपकी APK बन रही है...");
        put("progress_wait", "Please wait...", "कृपया इंतज़ार करें...");
        put("msg_prepare", "Preparing your app...", "आपका app तैयार हो रहा है...");
        put("msg_build", "Building your APK...", "आपकी APK बन रही है...");
        put("msg_almost", "Almost ready...", "लगभग तैयार...");

        put("done_title", "🎉 APK Ready!", "🎉 APK तैयार है!");
        put("done_text", "Your app has been created successfully.", "आपका app सफलतापूर्वक बन गया है।");
        put("install", "📱 Install APK", "📱 APK Install करें");
        put("share", "📤 Share APK", "📤 APK Share करें");
        put("location", "📁 Open Location", "📁 Location खोलें");
        put("done", "Done", "हो गया");
        put("saved_in", "Saved in Downloads: ", "Downloads में सेव हुई: ");
        put("saved_cache", "Your APK is ready. Tap Install or Share.", "आपकी APK तैयार है। Install या Share दबाएं।");
        put("allow_install", "Allow this app to install apps, then come back and tap Install again.",
                "इस app को install की अनुमति दें, फिर वापस आकर Install दोबारा दबाएं।");
        put("no_installer", "Could not open the installer.", "Installer नहीं खुल सका।");

        put("try_again", "Try Again", "फिर कोशिश करें");
        put("show_details", "Show Details", "Details दिखाएं");
        put("hide_details", "Hide Details", "Details छिपाएं");
        put("err_build",
                "APK could not be created. Please check your HTML file or ZIP project and try again.",
                "APK नहीं बन पाई। कृपया अपनी HTML file या ZIP project को दोबारा check करें और फिर कोशिश करें।");
        put("err_choose_first", "Please choose your HTML project first.", "पहले अपना HTML project चुनें।");
        put("err_no_index",
                "index.html was not found. Please choose an HTML project that contains index.html.",
                "index.html नहीं मिला। कृपया ऐसा HTML project चुनें जिसमें index.html मौजूद हो।");
        put("err_zip", "This ZIP file could not be opened. Please choose a valid ZIP.",
                "यह ZIP file खुल नहीं सकी। कृपया सही ZIP चुनें।");
        put("err_folder", "This folder could not be opened. Please choose it again.",
                "यह folder खुल नहीं सका। कृपया दोबारा चुनें।");
        put("err_unreadable", "This project could not be read. Please choose it again.",
                "यह project पढ़ा नहीं जा सका। कृपया दोबारा चुनें।");
        put("err_empty", "This project is empty. Please choose a project with your HTML files.",
                "यह project खाली है। कृपया अपनी HTML files वाला project चुनें।");

        put("missing_title", "Some files were not found", "कुछ files नहीं मिलीं");
        put("missing_text", "Your page uses files that are not in the project:\n\n",
                "आपका page ऐसी files इस्तेमाल करता है जो project में नहीं हैं:\n\n");
        put("missing_tail", "\n\nYour app may look incomplete. Create it anyway?",
                "\n\nआपका app अधूरा दिख सकता है। फिर भी बनाएं?");
        put("continue", "Create anyway", "फिर भी बनाएं");
        put("cancel", "Cancel", "रद्द करें");
    }

    private static void put(String key, String en, String hi) {
        EN.put(key, en);
        HI.put(key, hi);
    }

    private Strings() {}

    static String t(String key) {
        String v = (hindi ? HI : EN).get(key);
        return v != null ? v : key;
    }

    static boolean isHindi() { return hindi; }

    static void load(Context c) {
        hindi = prefs(c).getBoolean("hindi", false);
    }

    static void setHindi(Context c, boolean value) {
        hindi = value;
        prefs(c).edit().putBoolean("hindi", value).apply();
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("settings", Context.MODE_PRIVATE);
    }
}
