package com.htmlapk.creator;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** App name से अपने-आप सुरक्षित package id बनाता है (user को package name नहीं लिखना पड़ता). */
final class AppIdentity {
    static final String DEFAULT_NAME = "My App";
    private static final String PREFIX = "com.htmlapk.app.";
    private static final Set<String> RESERVED = new HashSet<>(Arrays.asList(
            "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", "const",
            "continue", "default", "do", "double", "else", "enum", "extends", "final", "finally", "float",
            "for", "goto", "if", "implements", "import", "instanceof", "int", "interface", "long", "native",
            "new", "package", "private", "protected", "public", "return", "short", "static", "strictfp",
            "super", "switch", "synchronized", "this", "throw", "throws", "transient", "try", "void",
            "volatile", "while", "true", "false", "null"));

    private AppIdentity() {}

    static String cleanName(String raw) {
        String n = raw == null ? "" : raw.trim().replaceAll("\\s+", " ");
        if (n.isEmpty()) n = DEFAULT_NAME;
        return n.length() > 50 ? n.substring(0, 50).trim() : n;
    }

    static String packageName(String appName) {
        String name = cleanName(appName);
        StringBuilder slug = new StringBuilder();
        boolean droppedLetters = false;
        for (int i = 0; i < name.length(); i++) {
            char c = name.charAt(i);
            if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) slug.append(c);
            else if (c > 127 && Character.isLetterOrDigit(c)) droppedLetters = true; // हिंदी आदि
        }
        String s = slug.toString().toLowerCase(Locale.ROOT);
        if (s.length() > 30) s = s.substring(0, 30);
        if (s.isEmpty() || Character.isDigit(s.charAt(0))) s = "app" + s;
        if (RESERVED.contains(s)) s = s + "app";
        if (droppedLetters) s = s + Integer.toHexString(name.hashCode() & 0xffff);
        return PREFIX + s;
    }

    static String fileName(String appName) {
        String s = cleanName(appName).replaceAll("[\\\\/:*?\"<>|]+", "").replace(' ', '_');
        return (s.isEmpty() ? "MyApp" : s) + ".apk";
    }
}
