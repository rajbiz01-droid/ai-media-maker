package com.htmlapk.creator;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Binary AndroidManifest.xml (AXML) की string pool में strings बदलता है,
 * और resources.arsc में package name लिखता है. सिर्फ java.* इस्तेमाल करता है.
 */
public final class AxmlPatcher {
    private static final int RES_STRING_POOL = 0x0001;
    private static final int RES_XML = 0x0003;
    private static final int RES_TABLE_PACKAGE = 0x0200;
    private static final int UTF8_FLAG = 0x100;

    private AxmlPatcher() {}

    /** map में जिस string की पूरी value मेल खाए, उसे नई value से बदल देता है. */
    public static byte[] replaceStrings(byte[] data, Map<String, String> map) {
        ByteBuffer in = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
        if ((in.getShort(0) & 0xffff) != RES_XML) throw new IllegalArgumentException("AXML नहीं है");
        int fileHeader = in.getShort(2) & 0xffff;
        int pool = fileHeader;
        if ((in.getShort(pool) & 0xffff) != RES_STRING_POOL) throw new IllegalArgumentException("String pool नहीं मिला");

        int headerSize = in.getShort(pool + 2) & 0xffff;
        int poolSize = in.getInt(pool + 4);
        int stringCount = in.getInt(pool + 8);
        int styleCount = in.getInt(pool + 12);
        int flags = in.getInt(pool + 16);
        int stringsStart = in.getInt(pool + 20);
        int stylesStart = in.getInt(pool + 24);
        boolean utf8 = (flags & UTF8_FLAG) != 0;

        List<String> strings = new ArrayList<>(stringCount);
        int offsetsAt = pool + headerSize;
        for (int i = 0; i < stringCount; i++) {
            int off = in.getInt(offsetsAt + i * 4);
            strings.add(readString(in, pool + stringsStart + off, utf8));
        }

        byte[] styleOffsets = new byte[styleCount * 4];
        System.arraycopy(data, offsetsAt + stringCount * 4, styleOffsets, 0, styleOffsets.length);
        byte[] styleData = new byte[0];
        if (styleCount > 0) {
            styleData = new byte[pool + poolSize - (pool + stylesStart)];
            System.arraycopy(data, pool + stylesStart, styleData, 0, styleData.length);
        }

        // नए strings encode करो
        ByteArrayOutputStream blob = new ByteArrayOutputStream();
        int[] newOffsets = new int[stringCount];
        for (int i = 0; i < stringCount; i++) {
            String s = strings.get(i);
            String r = map.get(s);
            if (r != null) s = r;
            newOffsets[i] = blob.size();
            writeString(blob, s, utf8);
        }
        while (blob.size() % 4 != 0) blob.write(0);

        int newStringsStart = headerSize + stringCount * 4 + styleCount * 4;
        int newStylesStart = styleCount > 0 ? newStringsStart + blob.size() : 0;
        int newPoolSize = newStringsStart + blob.size() + styleData.length;

        ByteBuffer out = ByteBuffer.allocate(newPoolSize).order(ByteOrder.LITTLE_ENDIAN);
        out.put(data, pool, headerSize);
        out.putInt(4, newPoolSize);
        out.putInt(20, newStringsStart);
        out.putInt(24, newStylesStart);
        out.position(headerSize);
        for (int o : newOffsets) out.putInt(o);
        out.put(styleOffsets);
        out.put(blob.toByteArray());
        out.put(styleData);

        int restStart = pool + poolSize;
        int restLen = data.length - restStart;
        ByteBuffer result = ByteBuffer.allocate(fileHeader + newPoolSize + restLen).order(ByteOrder.LITTLE_ENDIAN);
        result.put(data, 0, fileHeader);
        result.put(out.array(), 0, newPoolSize);
        result.put(data, restStart, restLen);
        result.putInt(4, result.capacity());
        return result.array();
    }

    /** resources.arsc के package chunk में नाम लिखता है (128 UTF-16 chars की fixed जगह). */
    public static void setArscPackageName(byte[] arsc, String name) {
        if (name.length() > 127) throw new IllegalArgumentException("Package name बहुत लंबा है");
        ByteBuffer b = ByteBuffer.wrap(arsc).order(ByteOrder.LITTLE_ENDIAN);
        int pos = b.getShort(2) & 0xffff;
        while (pos + 8 <= arsc.length) {
            int type = b.getShort(pos) & 0xffff;
            int size = b.getInt(pos + 4);
            if (size <= 0) break;
            if (type == RES_TABLE_PACKAGE) {
                int nameAt = pos + 12;
                for (int i = 0; i < 128; i++) {
                    b.putShort(nameAt + i * 2, (short) (i < name.length() ? name.charAt(i) : 0));
                }
            }
            pos += size;
        }
    }

    // ---- string pool encode/decode ----
    private static String readString(ByteBuffer b, int p, boolean utf8) {
        if (utf8) {
            int[] r = readLen8(b, p);               // UTF-16 length (छोड़ देते हैं)
            int[] r2 = readLen8(b, r[1]);           // byte length
            byte[] bytes = new byte[r2[0]];
            for (int i = 0; i < bytes.length; i++) bytes[i] = b.get(r2[1] + i);
            return new String(bytes, StandardCharsets.UTF_8);
        }
        int len = b.getShort(p) & 0xffff;
        p += 2;
        if ((len & 0x8000) != 0) {
            len = ((len & 0x7fff) << 16) | (b.getShort(p) & 0xffff);
            p += 2;
        }
        char[] chars = new char[len];
        for (int i = 0; i < len; i++) chars[i] = (char) (b.getShort(p + i * 2) & 0xffff);
        return new String(chars);
    }

    private static int[] readLen8(ByteBuffer b, int p) {
        int v = b.get(p) & 0xff;
        p++;
        if ((v & 0x80) != 0) {
            v = ((v & 0x7f) << 8) | (b.get(p) & 0xff);
            p++;
        }
        return new int[] {v, p};
    }

    private static void writeString(ByteArrayOutputStream o, String s, boolean utf8) {
        if (utf8) {
            byte[] bytes = s.getBytes(StandardCharsets.UTF_8);
            writeLen8(o, s.length());
            writeLen8(o, bytes.length);
            o.write(bytes, 0, bytes.length);
            o.write(0);
        } else {
            int len = s.length();
            if (len > 0x7fff) {
                int hi = (len >> 16) | 0x8000;
                o.write(hi & 0xff); o.write((hi >> 8) & 0xff);
                o.write(len & 0xff); o.write((len >> 8) & 0xff);
            } else {
                o.write(len & 0xff); o.write((len >> 8) & 0xff);
            }
            for (int i = 0; i < len; i++) {
                char c = s.charAt(i);
                o.write(c & 0xff); o.write((c >> 8) & 0xff);
            }
            o.write(0); o.write(0);
        }
    }

    private static void writeLen8(ByteArrayOutputStream o, int len) {
        if (len > 0x7f) {
            o.write((len >> 8) | 0x80);
            o.write(len & 0xff);
        } else {
            o.write(len);
        }
    }
}
