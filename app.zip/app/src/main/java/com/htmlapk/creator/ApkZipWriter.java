package com.htmlapk.creator;

import java.io.Closeable;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * APK के लिए ZIP writer. resources.arsc जैसी "stored" files 4-byte aligned रखता है
 * (Android 11+ में target SDK 30+ वाले apps के लिए जरूरी).
 */
public final class ApkZipWriter implements Closeable {
    private static class Counting extends FilterOutputStream {
        long count;
        Counting(OutputStream o) { super(o); }
        @Override public void write(int b) throws IOException { out.write(b); count++; }
        @Override public void write(byte[] b, int off, int len) throws IOException { out.write(b, off, len); count += len; }
    }

    private final Counting counting;
    private final ZipOutputStream zip;

    public ApkZipWriter(OutputStream out) {
        counting = new Counting(out);
        zip = new ZipOutputStream(counting);
        zip.setLevel(6);
    }

    public void addCompressed(String name, byte[] data) throws IOException {
        ZipEntry e = new ZipEntry(name);
        e.setMethod(ZipEntry.DEFLATED);
        zip.putNextEntry(e);
        zip.write(data);
        zip.closeEntry();
    }

    public void addCompressed(String name, InputStream in) throws IOException {
        ZipEntry e = new ZipEntry(name);
        e.setMethod(ZipEntry.DEFLATED);
        zip.putNextEntry(e);
        byte[] buf = new byte[64 * 1024];
        int n;
        while ((n = in.read(buf)) != -1) zip.write(buf, 0, n);
        zip.closeEntry();
    }

    public void addStoredAligned(String name, byte[] data) throws IOException {
        ZipEntry e = new ZipEntry(name);
        e.setMethod(ZipEntry.STORED);
        e.setSize(data.length);
        e.setCompressedSize(data.length);
        CRC32 crc = new CRC32();
        crc.update(data);
        e.setCrc(crc.getValue());

        int nameLen = name.getBytes("UTF-8").length;
        long base = counting.count + 30 + nameLen + 4;      // 4 = extra field header
        int pad = (int) ((4 - (base % 4)) % 4);
        byte[] extra = new byte[4 + pad];
        extra[0] = (byte) 0x35; extra[1] = (byte) 0xD9;       // zipalign का extra id
        extra[2] = (byte) pad;
        e.setExtra(extra);

        zip.putNextEntry(e);
        zip.write(data);
        zip.closeEntry();
    }

    @Override public void close() throws IOException { zip.close(); }
}
