package com.htmlapk.creator;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Build से पहले project जांचता है: खाली तो नहीं, पढ़ने लायक है, और जुड़ी files मौजूद हैं. */
final class ProjectValidator {
    static final class Result {
        final boolean empty;
        final boolean unreadable;
        final List<String> missing;

        Result(boolean empty, boolean unreadable, List<String> missing) {
            this.empty = empty;
            this.unreadable = unreadable;
            this.missing = missing;
        }
    }

    private static final Pattern REF = Pattern.compile("(?i)\\b(?:src|href|poster)\\s*=\\s*([\"'])(.*?)\\1");
    private static final Pattern EXTERNAL = Pattern.compile("(?i)^(?:[a-z][a-z0-9+.-]*:|//|#)");

    private ProjectValidator() {}

    static Result validate(File webRoot) {
        File index = findIndex(webRoot);
        if (index == null || countFiles(webRoot) == 0 || index.length() == 0) {
            return new Result(true, false, new ArrayList<String>());
        }
        String html;
        try {
            html = read(index);
        } catch (IOException e) {
            return new Result(false, true, new ArrayList<String>());
        }

        Set<String> missing = new LinkedHashSet<>();
        Matcher m = REF.matcher(html);
        while (m.find() && missing.size() < 50) {
            String ref = m.group(2).trim();
            if (ref.isEmpty() || EXTERNAL.matcher(ref).find()) continue;
            ref = ref.replaceAll("[?#].*$", "");
            if (ref.isEmpty() || ref.endsWith("/")) continue;
            try {
                ref = URLDecoder.decode(ref.replace("+", "%2B"), "UTF-8");
            } catch (Exception ignored) { }
            File target = ref.startsWith("/") ? new File(webRoot, ref.substring(1)) : new File(index.getParentFile(), ref);
            if (!target.exists()) missing.add(ref);
        }
        return new Result(false, false, new ArrayList<>(missing));
    }

    private static File findIndex(File dir) {
        File[] files = dir.listFiles();
        if (files == null) return null;
        for (File f : files) if (f.isFile() && f.getName().equalsIgnoreCase("index.html")) return f;
        return null;
    }

    private static int countFiles(File dir) {
        File[] files = dir.listFiles();
        if (files == null) return 0;
        int n = 0;
        for (File f : files) {
            if (ProjectImporter.IGNORED.contains(f.getName())) continue;
            n += f.isDirectory() ? countFiles(f) : 1;
        }
        return n;
    }

    private static String read(File f) throws IOException {
        byte[] buf = new byte[(int) Math.min(f.length(), 2L * 1024 * 1024)];
        try (FileInputStream in = new FileInputStream(f)) {
            int off = 0, n;
            while (off < buf.length && (n = in.read(buf, off, buf.length - off)) > 0) off += n;
        }
        return new String(buf, StandardCharsets.UTF_8);
    }
}
