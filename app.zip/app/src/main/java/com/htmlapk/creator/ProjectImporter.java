package com.htmlapk.creator;

import android.content.Context;
import android.net.Uri;

import androidx.documentfile.provider.DocumentFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** ZIP या Folder को cache में कॉपी करके index.html वाला web root ढूंढता है. */
final class ProjectImporter {
    /** UserException.message अब Strings का key है (भाषा के हिसाब से दिखता है). */
    static final String NOT_FOUND = "err_no_index";
    static final Set<String> IGNORED = new HashSet<>(Arrays.asList("__MACOSX", "node_modules", ".git"));

    static class UserException extends Exception {
        UserException(String message) { super(message); }
    }

    private ProjectImporter() {}

    static File stageZip(Context ctx, Uri uri) throws Exception {
        File stage = freshStage(ctx);
        String root = stage.getCanonicalPath() + File.separator;
        try (InputStream raw = ctx.getContentResolver().openInputStream(uri);
             ZipInputStream zin = new ZipInputStream(raw)) {
            ZipEntry e;
            while ((e = zin.getNextEntry()) != null) {
                String name = e.getName();
                if (name.startsWith("__MACOSX")) continue;
                File target = new File(stage, name);
                if (!target.getCanonicalPath().startsWith(root)) continue; // zip-slip से बचाव
                if (e.isDirectory()) { target.mkdirs(); continue; }
                target.getParentFile().mkdirs();
                try (OutputStream out = new FileOutputStream(target)) { copy(zin, out); }
            }
        } catch (IOException ex) {
            throw new UserException("err_zip");
        }
        return requireWebRoot(stage);
    }

    /** अकेली HTML file: उसे index.html बनाकर रखो. */
    static File stageHtml(Context ctx, Uri uri) throws Exception {
        File stage = freshStage(ctx);
        try (InputStream in = ctx.getContentResolver().openInputStream(uri);
             OutputStream out = new FileOutputStream(new File(stage, "index.html"))) {
            if (in == null) throw new IOException("null stream");
            copy(in, out);
        } catch (IOException ex) {
            throw new UserException("err_unreadable");
        }
        return stage;
    }

    static File stageTree(Context ctx, Uri treeUri) throws Exception {
        File stage = freshStage(ctx);
        DocumentFile root = DocumentFile.fromTreeUri(ctx, treeUri);
        if (root == null) throw new UserException("err_folder");
        copyDoc(ctx, root, stage);
        return requireWebRoot(stage);
    }

    private static void copyDoc(Context ctx, DocumentFile dir, File dest) throws IOException {
        for (DocumentFile f : dir.listFiles()) {
            String name = f.getName();
            if (name == null || IGNORED.contains(name)) continue;
            File target = new File(dest, name);
            if (f.isDirectory()) {
                target.mkdirs();
                copyDoc(ctx, f, target);
            } else {
                try (InputStream in = ctx.getContentResolver().openInputStream(f.getUri());
                     OutputStream out = new FileOutputStream(target)) {
                    if (in != null) copy(in, out);
                }
            }
        }
    }

    private static File requireWebRoot(File stage) throws UserException {
        File root = findWebRoot(stage);
        if (root == null) throw new UserException(NOT_FOUND);
        return root;
    }

    /** index.html जिस folder में सबसे ऊपर मिले (root में न हो तो recursive search). */
    static File findWebRoot(File dir) {
        List<File> level = new ArrayList<>();
        level.add(dir);
        while (!level.isEmpty()) {
            List<File> next = new ArrayList<>();
            for (File current : level) {
                File[] files = current.listFiles();
                if (files == null) continue;
                Arrays.sort(files, Comparator.comparing(File::getName));
                for (File f : files) {
                    if (f.isFile() && f.getName().equalsIgnoreCase("index.html")) return current;
                }
                for (File f : files) {
                    if (f.isDirectory() && !IGNORED.contains(f.getName())) next.add(f);
                }
            }
            level = next;
        }
        return null;
    }

    private static File freshStage(Context ctx) {
        File stage = new File(ctx.getCacheDir(), "stage");
        deleteRecursive(stage);
        stage.mkdirs();
        return stage;
    }

    static void deleteRecursive(File f) {
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteRecursive(k);
        f.delete();
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[64 * 1024];
        int n;
        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
    }
}
