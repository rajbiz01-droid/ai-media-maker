package com.htmlapk.creator;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.provider.Settings;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/** तैयार APK को सेव, install, share करना और उसकी location खोलना. */
final class OutputManager {
    private static final String APK_MIME = "application/vnd.android.package-archive";

    private OutputManager() {}

    /** Downloads folder में कॉपी करता है; सफल हो तो फ़ाइल का नाम लौटाता है. */
    static String saveToDownloads(Context ctx, File apk, String fileName) throws IOException {
        ContentValues v = new ContentValues();
        v.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
        v.put(MediaStore.Downloads.MIME_TYPE, APK_MIME);
        v.put(MediaStore.Downloads.RELATIVE_PATH, "Download");
        Uri uri = ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        if (uri == null) throw new IOException("insert failed");
        try (InputStream in = new FileInputStream(apk);
             OutputStream out = ctx.getContentResolver().openOutputStream(uri)) {
            if (out == null) throw new IOException("no stream");
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        }
        return fileName;
    }

    private static Uri shareUri(Context ctx, File apk) {
        return FileProvider.getUriForFile(ctx, ctx.getPackageName() + ".fileprovider", apk);
    }

    /** false = अनुमति नहीं थी, settings खोल दी गई. */
    static boolean install(Activity a, File apk) {
        if (!a.getPackageManager().canRequestPackageInstalls()) {
            a.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + a.getPackageName())));
            return false;
        }
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(shareUri(a, apk), APK_MIME);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        a.startActivity(i);
        return true;
    }

    static void share(Activity a, File apk) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType(APK_MIME);
        i.putExtra(Intent.EXTRA_STREAM, shareUri(a, apk));
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        a.startActivity(Intent.createChooser(i, null));
    }

    static void openLocation(Activity a) {
        a.startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS));
    }
}
