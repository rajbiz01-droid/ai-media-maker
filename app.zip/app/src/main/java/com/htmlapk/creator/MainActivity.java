package com.htmlapk.creator;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.res.ColorStateList;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static com.htmlapk.creator.Strings.t;

/**
 * सिर्फ UI. Project import, validation और build दूसरी classes करती हैं;
 * Build engine BuildEngine interface के पीछे है (बाद में बदला जा सकता है).
 */
public class MainActivity extends Activity {
    private static final int REQ_HTML = 1, REQ_ZIP = 2, REQ_TREE = 3, REQ_ICON = 4;
    private static final int INK = 0xFF14151A, MUTED = 0xFF5D6070, PRIMARY = 0xFF4F46E5,
            SECONDARY_BG = 0xFFEEF0FF, PAGE_BG = 0xFFF7F8FB;

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private BuildEngine engine;

    // state (भाषा बदलने पर भी बना रहता है)
    private File webRoot;
    private String projectName = "";
    private int projectState;            // 0 = कुछ नहीं, 1 = पढ़ रहे हैं, 2 = तैयार
    private Uri iconUri;
    private String appName = "";
    private String inlineError = "";
    private File builtApk;
    private String savedNote = "";
    private String lastDetails = "";
    private boolean busy;
    private Runnable currentScreen;

    // main-screen views
    private EditText nameInput;
    private TextView projectInfo;
    // progress views
    private ProgressBar progressBar;
    private TextView progressPercent, progressMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Strings.load(this);
        engine = new LocalPatchEngine(this);
        showMain();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (!busy) super.onBackPressed();
    }

    // ================================================================= screens
    private void showMain() {
        currentScreen = this::showMain;
        LinearLayout col = screen();
        languageSwitch(col);

        col.addView(text("HTML → APK", 30, INK, true));
        TextView sub = text(t("subtitle"), 16, MUTED, false);
        sub.setPadding(0, dp(6), 0, dp(22));
        col.addView(sub);

        // Step 1
        LinearLayout c1 = card(col);
        c1.addView(label(t("step1")));
        Button pick = secondary(t("choose_html"), 18);
        pick.setPadding(dp(16), dp(20), dp(16), dp(20));
        pick.setOnClickListener(v -> chooseProjectType());
        c1.addView(pick, new LinearLayout.LayoutParams(-1, -2));
        projectInfo = info("");
        c1.addView(projectInfo);
        refreshProjectInfo();

        // Step 2
        LinearLayout c2 = card(col);
        c2.addView(label(t("step2")));
        nameInput = new EditText(this);
        nameInput.setHint(t("name_hint"));
        nameInput.setText(appName);
        nameInput.setSingleLine(true);
        nameInput.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        GradientDrawable g = rounded(Color.WHITE, 12);
        g.setStroke(dp(1.5f), 0xFFE3E5EE);
        nameInput.setBackground(g);
        nameInput.setPadding(dp(14), dp(14), dp(14), dp(14));
        c2.addView(nameInput, new LinearLayout.LayoutParams(-1, -2));

        // Step 3
        LinearLayout c3 = card(col);
        c3.addView(label(t("step3")));
        Button pickIcon = secondary(t("choose_icon"), 18);
        pickIcon.setPadding(dp(16), dp(18), dp(16), dp(18));
        pickIcon.setOnClickListener(v -> openIconPicker());
        c3.addView(pickIcon, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout iconRow = new LinearLayout(this);
        iconRow.setGravity(Gravity.CENTER_VERTICAL);
        iconRow.setPadding(0, dp(10), 0, 0);
        if (iconUri != null) {
            ImageView preview = new ImageView(this);
            preview.setScaleType(ImageView.ScaleType.CENTER_CROP);
            preview.setImageURI(iconUri);
            LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(dp(44), dp(44));
            pl.rightMargin = dp(12);
            iconRow.addView(preview, pl);
        }
        TextView iconInfo = text(iconUri != null ? t("icon_chosen") : t("icon_default"), 14, MUTED, false);
        iconRow.addView(iconInfo);
        c3.addView(iconRow);

        // Create
        Button create = new Button(this);
        create.setText(t("create"));
        create.setAllCaps(false);
        create.setTextColor(Color.WHITE);
        create.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        create.setTypeface(Typeface.DEFAULT_BOLD);
        create.setStateListAnimator(null);
        create.setBackground(rounded(Color.BLACK, 16));
        create.setPadding(dp(16), dp(22), dp(16), dp(22));
        create.setOnClickListener(v -> onCreateClicked());
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-1, -2);
        cl.topMargin = dp(6);
        col.addView(create, cl);

        if (!inlineError.isEmpty()) {
            TextView err = text(inlineError, 15, 0xFFB42318, false);
            err.setBackground(rounded(0xFFFFF1F1, 12));
            err.setPadding(dp(14), dp(12), dp(14), dp(12));
            LinearLayout.LayoutParams el = new LinearLayout.LayoutParams(-1, -2);
            el.topMargin = dp(14);
            col.addView(err, el);
        }
    }

    private void showProgress() {
        currentScreen = null;
        LinearLayout col = screen();
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(0, dp(120), 0, 0);

        TextView title = text(t("progress_title"), 24, INK, true);
        title.setGravity(Gravity.CENTER);
        col.addView(title, new LinearLayout.LayoutParams(-1, -2));

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgressTintList(ColorStateList.valueOf(PRIMARY));
        progressBar.setProgressBackgroundTintList(ColorStateList.valueOf(SECONDARY_BG));
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, dp(14));
        bl.topMargin = dp(36);
        col.addView(progressBar, bl);

        progressPercent = text("0%", 20, INK, true);
        progressPercent.setGravity(Gravity.CENTER);
        progressPercent.setPadding(0, dp(14), 0, 0);
        col.addView(progressPercent, new LinearLayout.LayoutParams(-1, -2));

        progressMessage = text(t("msg_prepare"), 16, MUTED, false);
        progressMessage.setGravity(Gravity.CENTER);
        progressMessage.setPadding(0, dp(10), 0, 0);
        col.addView(progressMessage, new LinearLayout.LayoutParams(-1, -2));

        TextView wait = text(t("progress_wait"), 14, MUTED, false);
        wait.setGravity(Gravity.CENTER);
        wait.setPadding(0, dp(24), 0, 0);
        col.addView(wait, new LinearLayout.LayoutParams(-1, -2));
    }

    private void showDone() {
        currentScreen = this::showDone;
        LinearLayout col = screen();
        languageSwitch(col);

        TextView title = text(t("done_title"), 28, INK, true);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(40), 0, dp(8));
        col.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView msg = text(t("done_text"), 16, MUTED, false);
        msg.setGravity(Gravity.CENTER);
        col.addView(msg, new LinearLayout.LayoutParams(-1, -2));

        TextView saved = text(savedNote, 14, MUTED, false);
        saved.setGravity(Gravity.CENTER);
        saved.setPadding(0, dp(8), 0, dp(28));
        col.addView(saved, new LinearLayout.LayoutParams(-1, -2));

        col.addView(bigButton(t("install"), true, v -> installApk()));
        col.addView(bigButton(t("share"), false, v -> {
            try { OutputManager.share(this, builtApk); } catch (Exception e) { toast(t("no_installer")); }
        }));
        col.addView(bigButton(t("location"), false, v -> {
            try { OutputManager.openLocation(this); } catch (Exception e) { toast(t("no_installer")); }
        }));
        col.addView(bigButton(t("done"), false, v -> resetAll()));
    }

    private void showError(String message, String details) {
        currentScreen = null;
        lastDetails = details == null ? "" : details;
        LinearLayout col = screen();

        TextView icon = text("😕", 48, INK, false);
        icon.setGravity(Gravity.CENTER);
        icon.setPadding(0, dp(48), 0, dp(12));
        col.addView(icon, new LinearLayout.LayoutParams(-1, -2));

        TextView msg = text(message, 18, INK, false);
        msg.setGravity(Gravity.CENTER);
        msg.setPadding(0, 0, 0, dp(28));
        col.addView(msg, new LinearLayout.LayoutParams(-1, -2));

        col.addView(bigButton(t("try_again"), true, v -> { inlineError = ""; showMain(); }));

        if (!lastDetails.isEmpty()) {
            final TextView details_ = text(lastDetails, 12, 0xFFE6E7EE, false);
            details_.setBackground(rounded(INK, 12));
            details_.setPadding(dp(12), dp(12), dp(12), dp(12));
            details_.setTextIsSelectable(true);
            details_.setVisibility(View.GONE);

            final Button toggle = secondary(t("show_details"), 14);
            toggle.setOnClickListener(v -> {
                boolean show = details_.getVisibility() != View.VISIBLE;
                details_.setVisibility(show ? View.VISIBLE : View.GONE);
                toggle.setText(show ? t("hide_details") : t("show_details"));
            });
            LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-2, -2);
            tl.gravity = Gravity.CENTER_HORIZONTAL;
            col.addView(toggle, tl);
            LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(-1, -2);
            dl.topMargin = dp(12);
            col.addView(details_, dl);
        }
    }

    // ================================================================= actions
    private void chooseProjectType() {
        if (busy) return;
        captureName();
        new AlertDialog.Builder(this)
                .setTitle(t("pick_title"))
                .setItems(new String[] {t("pick_html"), t("pick_zip"), t("pick_folder")}, (d, which) -> {
                    if (which == 2) {
                        startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_TREE);
                        return;
                    }
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    startActivityForResult(i, which == 0 ? REQ_HTML : REQ_ZIP);
                })
                .show();
    }

    private void openIconPicker() {
        captureName();
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        startActivityForResult(i, REQ_ICON);
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();

        if (requestCode == REQ_ICON) {
            iconUri = uri;
            showMain();
            return;
        }

        inlineError = "";
        webRoot = null;
        projectState = 1;
        projectName = displayName(uri);
        refreshProjectInfo();
        busy = true;
        io.execute(() -> {
            try {
                File root;
                if (requestCode == REQ_ZIP) root = ProjectImporter.stageZip(this, uri);
                else if (requestCode == REQ_HTML) root = ProjectImporter.stageHtml(this, uri);
                else root = ProjectImporter.stageTree(this, uri);
                ui.post(() -> {
                    busy = false;
                    webRoot = root;
                    projectState = 2;
                    refreshProjectInfo();
                });
            } catch (Throwable th) {
                ui.post(() -> {
                    busy = false;
                    projectState = 0;
                    if (th instanceof ProjectImporter.UserException) {
                        inlineError = t(th.getMessage());
                    } else {
                        inlineError = t("err_unreadable");
                    }
                    showMain();
                });
            }
        });
    }

    private void onCreateClicked() {
        if (busy) return;
        captureName();
        inlineError = "";
        if (webRoot == null) {
            inlineError = t("err_choose_first");
            showMain();
            return;
        }

        ProjectValidator.Result r = ProjectValidator.validate(webRoot);
        if (r.unreadable) { inlineError = t("err_unreadable"); showMain(); return; }
        if (r.empty) { inlineError = t("err_empty"); showMain(); return; }
        if (!r.missing.isEmpty()) { confirmMissing(r.missing); return; }
        startBuild();
    }

    private void confirmMissing(List<String> missing) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(5, missing.size()); i++) sb.append("• ").append(missing.get(i)).append('\n');
        if (missing.size() > 5) sb.append("…");
        new AlertDialog.Builder(this)
                .setTitle(t("missing_title"))
                .setMessage(t("missing_text") + sb.toString().trim() + t("missing_tail"))
                .setPositiveButton(t("continue"), (d, w) -> startBuild())
                .setNegativeButton(t("cancel"), null)
                .show();
    }

    private void startBuild() {
        final String name = AppIdentity.cleanName(appName);
        final String pkg = AppIdentity.packageName(name);
        final BuildEngine.Request request = new BuildEngine.Request(webRoot, name, pkg, iconUri);

        busy = true;
        showProgress();
        io.execute(() -> {
            try {
                File apk = engine.build(request, percent -> ui.post(() -> setProgress(percent)));
                String note;
                try {
                    note = t("saved_in") + OutputManager.saveToDownloads(this, apk, apk.getName());
                } catch (Exception e) {
                    note = t("saved_cache");
                }
                final String finalNote = note;
                ui.post(() -> {
                    busy = false;
                    builtApk = apk;
                    savedNote = finalNote;
                    showDone();
                });
            } catch (Throwable th) {
                ui.post(() -> {
                    busy = false;
                    showError(t("err_build"), stack(th));
                });
            }
        });
    }

    private void setProgress(int percent) {
        if (progressBar == null) return;
        progressBar.setProgress(percent);
        progressPercent.setText(percent + "%");
        progressMessage.setText(percent < 55 ? t("msg_prepare") : percent < 80 ? t("msg_build") : t("msg_almost"));
    }

    private void installApk() {
        try {
            if (!OutputManager.install(this, builtApk)) toast(t("allow_install"));
        } catch (Exception e) {
            toast(t("no_installer"));
        }
    }

    private void resetAll() {
        webRoot = null;
        projectState = 0;
        projectName = "";
        iconUri = null;
        appName = "";
        builtApk = null;
        inlineError = "";
        showMain();
    }

    // ================================================================= small helpers
    private void captureName() {
        if (nameInput != null) appName = nameInput.getText().toString();
    }

    private void refreshProjectInfo() {
        if (projectInfo == null) return;
        if (projectState == 1) {
            projectInfo.setTextColor(MUTED);
            projectInfo.setText(t("reading"));
        } else if (projectState == 2) {
            projectInfo.setTextColor(0xFF15803D);
            projectInfo.setText(t("project_ready") + projectName);
        } else {
            projectInfo.setText("");
        }
    }

    private String displayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, new String[] {OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) { }
        String last = uri.getLastPathSegment();
        if (last == null) return "";
        int slash = Math.max(last.lastIndexOf('/'), last.lastIndexOf(':'));
        return slash >= 0 ? last.substring(slash + 1) : last;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    private static String stack(Throwable th) {
        StringWriter sw = new StringWriter();
        th.printStackTrace(new PrintWriter(sw));
        return sw.toString();
    }

    // ================================================================= view helpers
    private LinearLayout screen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(PAGE_BG);
        scroll.setFillViewport(true);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(20), dp(16), dp(40));
        scroll.addView(page, new ViewGroup.LayoutParams(-1, -2));

        int width = Math.min(getResources().getDisplayMetrics().widthPixels - dp(32), dp(440));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(width, -2);
        lp.gravity = Gravity.CENTER_HORIZONTAL;
        page.addView(col, lp);

        setContentView(scroll);
        return col;
    }

    private void languageSwitch(LinearLayout col) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.END);
        row.setPadding(0, 0, 0, dp(18));
        row.addView(langLabel("English", !Strings.isHindi(), false));
        row.addView(text("  |  ", 14, MUTED, false));
        row.addView(langLabel("हिंदी", Strings.isHindi(), true));
        col.addView(row, new LinearLayout.LayoutParams(-1, -2));
    }

    private TextView langLabel(String s, boolean active, boolean hindi) {
        TextView tv = text(s, 14, active ? PRIMARY : MUTED, active);
        tv.setPadding(dp(8), dp(8), dp(8), dp(8));
        tv.setOnClickListener(v -> {
            captureName();
            Strings.setHindi(this, hindi);
            if (currentScreen != null) currentScreen.run();
        });
        return tv;
    }

    private Button bigButton(String label, boolean primary, View.OnClickListener l) {
        Button b = primary ? secondary(label, 18) : secondary(label, 17);
        if (primary) {
            b.setTextColor(Color.WHITE);
            b.setBackground(rounded(Color.BLACK, 16));
        }
        b.setPadding(dp(16), dp(18), dp(16), dp(18));
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(12);
        b.setLayoutParams(lp);
        return b;
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(s);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        tv.setTextColor(color);
        if (bold) tv.setTypeface(Typeface.DEFAULT_BOLD);
        return tv;
    }

    private TextView label(String s) {
        TextView tv = text(s, 16, INK, true);
        tv.setPadding(0, 0, 0, dp(12));
        return tv;
    }

    private TextView info(String s) {
        TextView tv = text(s, 14, MUTED, false);
        tv.setPadding(0, dp(10), 0, 0);
        return tv;
    }

    private LinearLayout card(LinearLayout parent) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(rounded(Color.WHITE, 16));
        c.setElevation(dp(4));
        c.setPadding(dp(18), dp(18), dp(18), dp(18));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(16);
        parent.addView(c, lp);
        return c;
    }

    private Button secondary(String s, float sp) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(PRIMARY);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setStateListAnimator(null);
        b.setBackground(rounded(SECONDARY_BG, 14));
        return b;
    }
}
