package com.htmlapk.creator;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import com.android.apksig.ApkSigner;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * बिना Gradle/SDK के, फ़ोन पर ही APK बनाता है:
 * तैयार template APK में package, app name, icon और HTML files बदलकर उसे sign करता है.
 */
final class LocalPatchEngine implements BuildEngine {
    private final Context ctx;

    static final String TEMPLATE_PACKAGE = "com.htmlapk.template";
    static final String LABEL_PLACEHOLDER = "__APP_NAME__";
    private static final Pattern ICON_ENTRY = Pattern.compile("^res/mipmap[^/]*/ic_launcher(_round)?\\.png$");

    LocalPatchEngine(Context context) {
        this.ctx = context.getApplicationContext();
    }

    @Override
    public File build(BuildEngine.Request r, BuildEngine.Progress p) throws Exception {
        File webRoot = r.webRoot;
        String appName = r.appName;
        String pkg = r.packageName;
        Uri iconUri = r.iconUri;
        File dir = new File(ctx.getCacheDir(), "apks");
        ProjectImporter.deleteRecursive(dir);
        dir.mkdirs();
        File unsigned = new File(dir, "unsigned.apk");
        File signed = new File(dir, AppIdentity.fileName(appName));

        p.on(20);
        Map<String, byte[]> entries = readTemplate();

        p.on(40);
        Map<String, String> repl = new HashMap<>();
        repl.put(TEMPLATE_PACKAGE, pkg);
        repl.put(LABEL_PLACEHOLDER, appName);
        entries.put("AndroidManifest.xml", AxmlPatcher.replaceStrings(entries.get("AndroidManifest.xml"), repl));
        byte[] arsc = entries.get("resources.arsc");
        if (arsc != null) AxmlPatcher.setArscPackageName(arsc, pkg);

        p.on(55);
        if (iconUri != null) {
            Bitmap src = decodeIcon(iconUri);
            for (String name : new HashSet<>(entries.keySet())) {
                if (ICON_ENTRY.matcher(name).matches()) entries.put(name, scaledPng(src, sizeFor(name)));
            }
        }

        p.on(70);
        try (FileOutputStream fo = new FileOutputStream(unsigned);
             ApkZipWriter zip = new ApkZipWriter(new java.io.BufferedOutputStream(fo))) {
            for (Map.Entry<String, byte[]> e : entries.entrySet()) {
                String name = e.getKey();
                if (name.equals("resources.arsc")) zip.addStoredAligned(name, e.getValue());
                else zip.addCompressed(name, e.getValue());
            }
            addWebFiles(zip, webRoot, "assets/www", true);
        }

        p.on(80);
        sign(unsigned, signed);
        unsigned.delete();

        p.on(100);
        return signed;
    }

    private Map<String, byte[]> readTemplate() throws IOException {
        Map<String, byte[]> map = new LinkedHashMap<>();
        try (InputStream in = ctx.getAssets().open("template.apk");
             ZipInputStream zin = new ZipInputStream(in)) {
            ZipEntry e;
            while ((e = zin.getNextEntry()) != null) {
                String name = e.getName();
                if (e.isDirectory() || name.startsWith("META-INF/") || name.startsWith("assets/www/")) continue;
                map.put(name, readAll(zin));
            }
        }
        if (!map.containsKey("AndroidManifest.xml")) throw new IOException("Template APK में manifest नहीं मिला");
        return map;
    }

    private static void addWebFiles(ApkZipWriter zip, File dir, String prefix, boolean root) throws IOException {
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (ProjectImporter.IGNORED.contains(f.getName())) continue;
            String fileName = root && f.getName().equalsIgnoreCase("index.html") ? "index.html" : f.getName();
            String name = prefix + "/" + fileName;
            if (f.isDirectory()) {
                addWebFiles(zip, f, name, false);
            } else {
                try (InputStream in = new FileInputStream(f)) { zip.addCompressed(name, in); }
            }
        }
    }

    private void sign(File in, File out) throws Exception {
        byte[] keyBytes = readAsset("keys/signing_key.pk8");
        byte[] certBytes = readAsset("keys/signing_cert.der");
        PrivateKey key = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(keyBytes));
        X509Certificate cert = (X509Certificate) CertificateFactory.getInstance("X.509")
                .generateCertificate(new ByteArrayInputStream(certBytes));

        ApkSigner.SignerConfig config = new ApkSigner.SignerConfig.Builder(
                "htmlapk", key, Collections.singletonList(cert)).build();
        new ApkSigner.Builder(Collections.singletonList(config))
                .setInputApk(in)
                .setOutputApk(out)
                .setMinSdkVersion(21)
                .setV1SigningEnabled(true)
                .setV2SigningEnabled(true)
                .build()
                .sign();
    }

    // ---- icon helpers ----
    private Bitmap decodeIcon(Uri uri) throws IOException {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream in = ctx.getContentResolver().openInputStream(uri)) { BitmapFactory.decodeStream(in, null, bounds); }
        int sample = 1;
        while (Math.max(bounds.outWidth, bounds.outHeight) / sample > 1024) sample *= 2;
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = sample;
        try (InputStream in = ctx.getContentResolver().openInputStream(uri)) {
            Bitmap bmp = BitmapFactory.decodeStream(in, null, opts);
            if (bmp == null) throw new IOException("Icon image पढ़ी नहीं जा सकी");
            return bmp;
        }
    }

    private static byte[] scaledPng(Bitmap src, int size) {
        int side = Math.min(src.getWidth(), src.getHeight());
        Bitmap square = Bitmap.createBitmap(src, (src.getWidth() - side) / 2, (src.getHeight() - side) / 2, side, side);
        Bitmap scaled = Bitmap.createScaledBitmap(square, size, size, true);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        scaled.compress(Bitmap.CompressFormat.PNG, 100, out);
        return out.toByteArray();
    }

    private static int sizeFor(String entryName) {
        if (entryName.contains("xxxhdpi")) return 192;
        if (entryName.contains("xxhdpi")) return 144;
        if (entryName.contains("xhdpi")) return 96;
        if (entryName.contains("hdpi")) return 72;
        return 48;
    }

    // ---- misc ----
    private byte[] readAsset(String name) throws IOException {
        try (InputStream in = ctx.getAssets().open(name)) { return readAll(in); }
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[16 * 1024];
        int n;
        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        return out.toByteArray();
    }
}
